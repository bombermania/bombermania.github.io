# -*- coding: utf-8 -*-
import pygame
import tkinter
import math
import random, time
import socket	
import os, sys
introarr = ['B', 'U', 'R', 'Y', 'A', 'T', ' ', 'E', 'N', 'T', 'E', 'R', 'T', 'A', 'I', 'M', 'E', 'N', 'T',' ','P', 'R', 'E', 'S', 'E', 'N', 'T']

WHITE = (255, 255, 255)
RED = (255,0,0)
YELLOW = (255,255,0)
GREEN = (0,	80,0)
BLUE = (0,0,255)
LIGHT_BLUE = (0,80,255)

x = 0
y = 0
turn = 'Enemy'
your_cards = []
your_activate_cards = []
activate_cards_position = [0,0,0]
player_cards = 0
player_activate_cards = 0
enemy_activate_cards = []
enemy_active_cards = 0
enemy_cards = []
enemys_cards = 0
#sock = socket.socket()
#sock.bind(('', 9090))
#sock.listen(1)
#conn, addr = sock.accept()

pygame.init()

from Source.music_load import *
from Source.image_load import *

title = 1
game = 1

hp = 100
mp = 10

enemyhp = 100
enemymp = 10
fpsClock = pygame.time.Clock()
maxh = 768
maxw = 1024
screen = pygame.display.set_mode((maxw,maxh))
''', pygame.FULLSCREEN'''
font = pygame.font.Font(os.path.join("fonts", 'Unifont.ttf'), 48)


class card():
	def __init__(self, x ,y, card_type, card_id, hp, mp):
		self.x = x
		self.y = y
		self.card_type = card_type
		self.card_id = card_id
		self.hp = hp
		self.mp = mp
	def draw(self, screen, cardholder):
		if (cardholder == 'player'):
			card_load = "images/Cards/card_" + str(self.card_type) + ".png"
			screen.blit(pygame.image.load(card_load),(self.x,self.y))
		else:
			screen.blit(enemy_card, (self.x, self.y))

class card_in_fight():
	def __init__(self, x ,y, card_type, hp, mp):
		self.x = x
		self.y = y
		self.hp = hp
		self.mp = mp
		self.card_type = card_type
	def draw(self, screen, cardholder):
		if (cardholder == 'player'):
			card_load = "images/Cards/card_" + str(self.card_type) + ".png"
			screen.blit(pygame.image.load(card_load),(self.x,self.y))
		if (cardholder == 'enemy'):
			card_load = "images/Cards/card_" + str(self.card_type) + ".png"
			screen.blit(pygame.image.load(card_load),(self.x,self.y))
	def get_attack(self, enemydmg):
		self.hp -= enemydmg
def card_use(card_id,tempx, tempy, card_type,cards,hp,mp):
	global player_activate_cards
	global player_cards
	tmp = 1
	if ((player_activate_cards) < 3 and (len(your_cards))) and (player_cards != 0):
		if ((activate_cards_position[0] == 0)):
			your_activate_cards.append(card_in_fight((100),(200),(card_type),(hp),(mp)))
			your_cards.pop(your_cards.index(cards))
			player_activate_cards += 1
			player_cards -=1
			activate_cards_position[0] = 1
		elif ((activate_cards_position[1] == 0)):
			your_activate_cards.append(card_in_fight((200),(300),(card_type),(hp),(mp)))
			your_cards.pop(your_cards.index(cards))
			player_activate_cards += 1
			player_cards -=1
			activate_cards_position[1] = 1
		elif ((activate_cards_position[2] == 0)):
			your_activate_cards.append(card_in_fight((100),(400),(card_type),(hp),(mp)))
			your_cards.pop(your_cards.index(cards))
			player_activate_cards += 1
			player_cards -=1
			activate_cards_position[2] = 1
		print("activate_cards_position:",activate_cards_position)
		print("player_cards:", player_cards)
		'''
		if ((your_activate_cards == 0)):
			tempx = tempx - 200
			your_activate_cards.append(card_in_fight((tempx),(tempy),(card_type)))
		if (len(your_activate_cards == 1)):
			your_activate_cards.append(card_in_fight((tempx),(tempy),(card_type)))
		if (len(your_activate_cards == 2)):
			your_activate_cards.append(card_in_fight((tempx),(tempy),(card_type)))
		if (len(your_activate_cards == 3)):
			your_activate_cards.append(card_in_fight((tempx),(tempy),(card_type)))
		'''
	else:
		print("Слишком много карт активированно")
		tmp = 0
	return tmp
def enemy_intelligence(card_id, x, y, card_type, cards, hp, mp):
	global enemy_active_cards
	global turn
	ret = 0
	if (turn == 'Enemy'):
		if (enemy_active_cards == 0):
			enemy_activate_cards.append(card_in_fight((620),(200),(card_type),(hp),(mp)))
			enemy_active_cards += 1
			ret = 1
		elif (enemy_active_cards == 1):
			temp = random.randint(0,2)
			if (tmp > 0):
				enemy_activate_cards.append(card_in_fight((520),(300),(card_type),(hp),(mp)))
				enemy_active_cards += 1
				ret = 1
			else:
				pass
		elif (enemy_active_cards == 2):
			temp = random.randint(0,2)
			if (tmp == 0):
				enemy_activate_cards.append(card_in_fight((620),(400),(card_type),(hp),(mp)))
				enemy_active_cards += 1
				ret = 1
			else:
				pass
		print(enemy_activate_cards)
		turn = 'Player'
	print(ret)
	return ret
	'''
	elif (enemy_activate_cards == 3): 
		temp = random.randint(0,3)
		if (tmp == 0):
			enemy_activate_cards.append(card_in_fight((200),(300),(card_type),(hp),(mp)))
		else: 
	'''
	
def draw_objects():
	font = pygame.font.Font(os.path.join("fonts", 'Unifont.ttf'), 12)
	screen.fill((71,74,81))
	screen.blit(bg, (0,0))
	text1 = font.render("Здоровье:" + str(hp), 1, (255,0,0))
	text2 = font.render("Энергия: " + str(mp), 1, (0,0,255))
	screen.blit(text1, (20,690))
	screen.blit(text2, (20,720))
	text1 = font.render("Здоровье:" + str(enemyhp), 1, (255,0,0))
	text2 = font.render("Энергия: " + str(enemymp), 1, (0,0,255))
	screen.blit(text1, (30,30))
	screen.blit(text2, (30,60))
	screen.blit(deck_of_cards,(770,-50))
	screen.blit(deck_of_cards,(770,400))
	if (enemys_cards == 0):
		cards_generate(1)
	if (player_cards == 0):
		cards_generate(0)
	for cards in your_activate_cards:
		cards.draw(screen, 'player')
		if (cards.hp <= 0):
			your_cards.pop(your_cards.index(cards))
	tmp = 1
	for cards in enemy_cards:
		if tmp:
			temp = enemy_intelligence(cards.card_id, cards.x, cards.y, cards.card_type, cards, hp, mp)
			if temp:
				enemy_cards.pop(enemy_cards.index(cards))
		tmp = 0
		cards.draw(screen, 'enemy')
	for cards in enemy_activate_cards:
		cards.draw(screen, 'enemy')
	for cards in your_cards:
		cards.draw(screen, 'player')
# второй одинаковый цикл для поверхностной отрисовки	
	for cards in your_cards:
		if (mousex >= cards.x) and (mousex <= cards.x + 140) and (mousey >= cards.y) and (mousey <= cards.y + 190):
			screen.blit(info_card, ((mousex),(mousey-210)))
			font = pygame.font.Font(os.path.join("fonts", 'Unifont.ttf'), 12)
			card_name = (open(str('Data/'+ str(cards.card_type) + '.chr')).read().split('\n')[0]).encode(encoding='UTF-8')
			screen.blit(font.render(card_name, 1, (0,0,255)), (cards.x, cards.y))
			#font.render
			print(card_name)
			#text1 = font.render(card_name, 1, (255,0,0))
			#text2 = font.render(card_name, 1, (0,0,255))
			#screen.blit(text1, (mousex, mousey - 200))
			#screen.blit(text2, (mousex - 150, mousey - 190))
				
		
def cards_generate(arrtype):
	global player_cards
	global enemys_cards
	if arrtype == 0:
		tempx = 300
		tempy = 570
		for i in range(0,3):
			temp = random.randint(1,3)
			card_get_sound.play(2)
			print(i)
			hp_card = answ1 = str(open(str('Data/'+ str(temp) + '.chr')).read().split('\n')[1]).encode('utf-8')
			mp_card = answ1 = str(open(str('Data/'+ str(temp) + '.chr')).read().split('\n')[2]).encode('utf-8')
			your_cards.append(card((tempx),(tempy),(temp),(i), (hp_card), (mp_card)))
			tempx += 145
			player_cards += 1
	elif arrtype == 1:
		tempx = 300
		tempy = -80
		for i in range(0,3):
			card_get_sound.play(2)
			temp = random.randint(1,3)
			hp_card = answ1 = str(open(str('Data/'+ str(temp) + '.chr')).read().split('\n')[1]).encode('utf-8')
			mp_card = answ1 = str(open(str('Data/'+ str(temp) + '.chr')).read().split('\n')[2]).encode('utf-8')
			enemy_cards.append(card((tempx),(tempy),(temp),(i),(hp_card), (mp_card)))
			tempx += 145
			enemys_cards += 1
	
while True:
	text = ''
	tmp = 0
	checktmp = 0
	i = 0
	tmp2 = 1
	screen.fill((0,0,0))
	while title:
		if tmp2:
			 intro_sound.play()
			 tmp2 = 0
		for event in pygame.event.get():
			if (event.type == pygame.QUIT):
				exit()
			elif event.type == pygame.MOUSEBUTTONDOWN:
				intro_sound.stop()
				font = pygame.font.Font(os.path.join("fonts", 'Unifont.ttf'), 24)
				title = 0
				break
		tmp += 1
		if (tmp == 15):
			checktmp +=1
			tmp = 0
		if i > 26:	
			time.sleep(14)
			font = pygame.font.Font(os.path.join("fonts", 'Unifont.ttf'), 24)
			title = 1
			break
		if (checktmp == 1):
			text += introarr[i]
			i += 1
			checktmp = 0
		screen.blit(font.render(text, 0, WHITE), (maxh//2-200, maxw//2))
		pygame.display.flip()
		fpsClock.tick(60)
		
	while game:
		mousex, mousey = pygame.mouse.get_pos()
		for event in pygame.event.get():
			if (event.type == pygame.QUIT):
				exit()
			elif (turn == 'Player'):	
				if event.type == pygame.MOUSEBUTTONDOWN:
					for cards in your_cards:
						if (event.button == 1) and (mousex >= cards.x) and (mousex <= cards.x + 140) and (mousey >= cards.y) and (mousey <= cards.y + 190):
							tmp = card_use(cards.card_id, cards.x, cards.y, cards.card_type, cards, hp, mp)
							print("cards: ", cards)
							if tmp:
								turn = 'Enemy'
		draw_objects()
		pygame.display.flip()
		fpsClock.tick(60)
		info = 'CARD GAME: ' + str(mousex) + ':' + str(mousey)
		pygame.display.set_caption(info)
pygame.quit()
