import pygame
pygame.init()
sound = pygame.mixer.Sound
intro_sound = sound('sounds/intro.ogg')
card_get_sound = sound('sounds/card_get.ogg')
card_use_spund = sound('sounds/card_get.ogg')
