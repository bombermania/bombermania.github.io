import pygame
pygame.init()
image = pygame.image.load

enemy_card = image('images/Cards/enemy_card.png')
your_card = image('images/Cards/your_card.png')
bg_game = image('images/bg.png')
card_bg = image('images/card_bg.png')
card_1 = image('images/Cards/card_1.png')
bg = image('images/bg.png')
deck_of_cards = image('images/deck_of_cards.png')
info_card = image('images/info.png')
