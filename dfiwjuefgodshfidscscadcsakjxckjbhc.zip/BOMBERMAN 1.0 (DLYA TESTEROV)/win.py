#from game import *  
import pygame
global win
#win = 1
win = 0
maxw = 660
maxh = 660

bg_menu = pygame.image.load('images/Menu/bg.png')
button = pygame.image.load('images/Menu/button.png')
button_on_click = pygame.image.load('images/Menu/button_on_click.png')

window = pygame.display.set_mode((maxw+120, maxh+40))
#def draw_win():
#	pass
def draw_win():
	global win
	pygame.time.delay(100)
	pygame.font.init()
	window.blit(bg_menu, (0,0))
	int_font = pygame.font.SysFont('Verdana',24)
	mousex, mousey = pygame.mouse.get_pos()	
	window.blit(button, ((maxw+120)/2-100,(maxh+40)/2 - 120))
	menu_button_1 = int_font.render("Меню" , 1, (255,0,0))
	window.blit(menu_button_1, ((maxw+120)/2 - 100+ 60, (maxh+40)/2 - 120))
	for event in pygame.event.get():
		if (event.type == pygame.QUIT):
			exit()
		if event.type == pygame.MOUSEBUTTONDOWN:
			#pass
			mousex, mousey = pygame.mouse.get_pos()
			if (event.type == 5) and (mousex > 290) and (mousex <= 490) and (mousey > 230) and(mousey <= 270):
				#game = 1
				menu = 1
				win = 0
	if (mousex > 290) and (mousex <= 490) and (mousey > 230) and(mousey <= 270):
		window.blit(button_on_click, ((maxw+120)/2 - 100, (maxh+40)/2 - 120))
		window.blit(menu_button_1, ((maxw+120)/2 - 100+ 60, (maxh+40)/2 - 120))

	pygame.display.flip()
while win:
	draw_win()
