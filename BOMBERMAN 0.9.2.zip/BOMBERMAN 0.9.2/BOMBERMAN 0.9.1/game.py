# -*- coding: utf-8 -*-
import pygame
import sys,os
from urllib.request import urlopen
import math
import random
import webbrowser
from tkinter import *
from Player import Player
from Blocks import wall
#from win import *
global gener
global win
win = 0
global pros 
pros = True
#import pro
pygame.init()
'''try:
    import pygame_sdl2
    pygame_sdl2.import_as_pygame()	
except ImportError:
    print("import error")
    pass
'''

#try:
#    import android
#except ImportError:
#    android=None
#    print("except")
#if android:
#	android.vibrate(0.05)
maxw = 660
maxh = 660
#640/40 = 16 / 2 = 8 движений в одну сторону максимально
maxbomb = []
#########################################################
# отвечает за процессы сцен
global menu
global typelvl
global levelh
global levelw
global icemax
menu = 1
global level_choice
level_choice = 0
global game
global hp
typelvl = 'Random1'
hp = 10
mp = 10
wait = 0
game = 0
#########################################################
galochka = pygame.image.load('images/Menu/Levels/completed.png')
lvlicon = [pygame.image.load('images/Menu/Levels/Very_Easy.png'),pygame.image.load('images/Menu/Levels/Easy.png'), pygame.image.load('images/Menu/Levels/Normal.png'), pygame.image.load('images/Menu/Levels/Some_Hard.png'),pygame.image.load ('images/Menu/Levels/Hard.png'),pygame.image.load('images/Menu/Levels/Very_Hard.png'),pygame.image.load('images/Menu/Levels/Hell.png'),pygame.image.load ('images/Menu/Levels/wtf.png')]
window = pygame.display.set_mode((maxw+120, maxh+40))
button = pygame.image.load('images/Menu/button.png')
button_on_click = pygame.image.load('images/Menu/button_on_click.png')
bg_menu = pygame.image.load('images/Menu/bg.png')
brick_menu = pygame.image.load('images/Menu/1.png')
gran = pygame.image.load('images/gran.png')
cursor = pygame.image.load(('images/system/cursor.png'))
background = pygame.image.load('images/backgrounds/bg.png')
gameover = pygame.image.load('images/backgrounds/gameover1.png')
walkright = [pygame.image.load('images/Hero/Right.png')]
walkleft = [pygame.image.load('images/Hero/Left.png')]
walkup = [pygame.image.load('images/Hero/Up.png')]
walkdown = [pygame.image.load('images/Hero/Down.png')]
nowalk = [pygame.image.load('images/Hero/Down.png')]
die = [pygame.image.load('images/Hero/Die.png')]
boom_start = pygame.image.load('images/Boom/boom_start.png')
default_down = pygame.image.load('images/Boom/default_down.png')
default_up = pygame.image.load('images/Boom/default_up.png')
default_left = pygame.image.load('images/Boom/default_left.png')
default_right = pygame.image.load('images/Boom/default_right.png')
end_up = pygame.image.load('images/Boom/end_up.png')
end_down = pygame.image.load('images/Boom/end_down.png')
end_left = pygame.image.load('images/Boom/end_left.png')
end_right = pygame.image.load('images/Boom/end_right.png')
bonusdraw = pygame.image.load('images/Bonus/bonus.png')
skillbad = pygame.image.load('images/Skills/bad_use.png')
skillgood = pygame.image.load('images/Skills/good_use.png')
skillfreeze = pygame.image.load('images/Skills/cant_use.png')
skillicon = [pygame.image.load('images/Skills/bomb.png'), pygame.image.load('images/Skills/bullet.png')]
bonusdraw1 = pygame.image.load('images/Bonus/bonus1.png')
block = [pygame.image.load('images/Blocks/block.png')]
ice_block = [pygame.image.load('images/Blocks/ice_block1.png')]
bat = [pygame.image.load('images/Enemy/bat_down.png'), pygame.image.load('images/Enemy/bat_up.png'), pygame.image.load('images/Enemy/bat_left.png'), pygame.image.load('images/Enemy/bat_right.png')]
bomba = [pygame.image.load('images/bomb0.png'), pygame.image.load('images/bomb1.png'), pygame.image.load('images/bomb2.png'), pygame.image.load('images/bomb3.png')]
##########################################################
#Настройки в самой библиотечке
pygame.font.init()
int_font = pygame.font.SysFont('Verdana',12)
pygame.mouse.set_visible(True) 
##########################################################
#Кортежи, для цветов
RED = (255,0,0)
YELLOW = (255,255,0)
GREEN = (0,	80,0)
BLUE = (0,0,255)
LIGHT_BLUE = (0,80,255)
##########################################################
# Персонаж
global x
players = []
global y
x = 10
y = 10
global spd
width = 40
height = 40
spd = 40
global died
global antidie 
antidie = False
died = False
##########################################################
from Player import Player
players.append(Player(10,10))
# Импорт персонажа
##########################################################
#Работа бомбы

global ax
global ay
global drawbomb
global boombombtime
global actbomb
ax = 0
ay = 0
boombombtime = 0
actbomb = False
##########################################################
# Враги
global enemymax
global enemycount
enemys = []
kills = 0
enemydo = False
enemymax = 1
enemyskills = ['right', 'left', 'up', 'down']
enemyneed = ' '
enemycount = 0
global enemylive 
enemylive = 0
##########################################################
# Стены
global x1
global y1
ice = []
cx = 50
##########################################################
# Бонусы
bonusarr = []
buffs = []
##########################################################
# Навыки
skills = []
bullets = []
global lastz
lastz = pygame.time.get_ticks()
global bombcooldown
bombcooldown = True
global bulletcooldown
bulletcooldown = True
direction = 'down'
##########################################################
AnimCount = 0
maxbomb = 5
maxdrawbomb = 0
currentbomb = 0
checkbomb = 0
bombs = []
clock = pygame.time.Clock()
drawbomb = False
global left
left = False
global right
right = False
global up
up = False
global down
down = False
positionbool = 'down'
##########################################################
###########################################################
def start_menu():
	pass
class Camera:
	def __init__(self, camera_func, w, h):
		self.camera_func = camera_func
		self.state = pygame.Rect(0, 0, w, h)
	def update(self):
		pass
		#self.state = self.camera_func(self.state, target.rect)
	def apply(self):
		return target.rect.move(self.state.topleft)
def camera_func(camera, target_rect):
	xcam = -x + maxw/2
	ycam = -y + maxh/2
	checkx = min(0,xcam)
	#проверка камеры на просмотр с края уровня
	checkx = max(-(levelw-maxw), checkx)
camera = Camera(camera_func, maxh, maxw)
#camera = Camera(camera_func, total_level_width, total_level_height)
class enemy():
	def __init__(self, x, y):
		self.x = x
		self.y = y
		self.hp = 10
		self.mp = 0
		self.last = pygame.time.get_ticks()
		self.cooldown = 300
		self.coolbool = True
		self.motion = 'down'
	def draw(self, window):
#		pygame.draw.rect(window, (0,255,0),(self.x,self.y, width, height))
		if (self.motion == 'down'):
			window.blit(bat[0], (self.x, self.y))
		if (self.motion == 'up'):
			window.blit(bat[1], (self.x, self.y))
		if (self.motion == 'left'):
			window.blit(bat[2], (self.x, self.y))
		if (self.motion == 'right'):
			window.blit(bat[3], (self.x, self.y))	
		#window.blit(bomba[0], (self.x, self.y))
		if (self.hp >= 1):
			pygame.draw.rect(window, RED, (self.x, self.y-10, round(4*self.hp),5))
		#pygame.display.update()
	def enemy_motion_cooldown(self):
		now = pygame.time.get_ticks()
		if (now - self.last >= self.cooldown):
			self.last = now
			self.coolbool = True
			return True
		else:
			return False
class blocked():
	def __init__(self, x, y):
		self.x = x
		self.y = y
#		self.direction = direction
	def draw(self,window,types):
		if (types == 2):
			window.blit(ice_block[0],(self.x, self.y))
		if (types == 1):
			window.blit(block[0], (self.x, self.y))
class skill():
	def __init__(self, x, y, cooldown, skilltype):
		self.x = x
		self.y = y
		self.last = pygame.time.get_ticks()
		self.skilltype = skilltype
		self.cooldown = cooldown
	def draw(self,window,lastz):
		self.last = lastz
		now = pygame.time.get_ticks()
		if (self.skilltype == 0):
			if (now - self.last < self.cooldown):
				window.blit(skillbad, (self.x, self.y))
			else:
				window.blit(skillgood, (self.x, self.y))
				global bombcooldown
				bombcooldown = True
			window.blit(skillicon[0], (self.x, self.y))
		if (self.skilltype == 1):
			if (now - self.last < self.cooldown):
				window.blit(skillbad,(self.x, self.y))
			else:
				global bulletcooldown
				bulletcooldown = True
				window.blit(skillgood, (self.x, self.y))
			window.blit(skillicon[1], (self.x, self.y))

class bomb():
	def __init__(self, x ,y):
		self.x = x
		self.y = y
		self.last = pygame.time.get_ticks()
		self.boomtime = 1000
		self.splash = True
		global died
	def boom(self):
		now = pygame.time.get_ticks()
		if (now - self.last >= self.cooldown):
			self.last = now
			self.splash = True
	def draw(self, window):
		global enemylive
		global hp
		global win
		global kills
		dleft = 0
		dup = 0
		dright = 0
		ddown = 0
		now = pygame.time.get_ticks()
		if (now - self.last < 500):
			window.blit(bomba[0], (self.x, self.y))
		elif (now - self.last <= 900):
			window.blit(bomba[1], (self.x, self.y))
		elif (now - self.last <= 1600):
			window.blit(bomba[2], (self.x, self.y))	
		elif (now - self.last <= 2000):
			window.blit(boom_start,(self.x, self.y))
			if (blockdefense(self.x,2,self.y,self.x-2*spd,self.y) and blockdefense(self.x,2,self.y,self.x-spd,self.y)):
				dleft = 2 * spd
				window.blit(default_left,(self.x-spd, self.y))
				window.blit(end_left,(self.x-2*spd, self.y))
			elif (blockdefense(self.x,2,self.y,self.x-spd, self.y)):
				dleft = spd
				window.blit(end_left, (self.x-spd, self.y))
			if (blockdefense(self.x,2,self.y,self.x+2*spd,self.y) and blockdefense(self.x,2,self.y,self.x+spd,self.y)):
				window.blit(default_right,(self.x+spd, self.y))
				window.blit(end_right,(self.x+2*spd, self.y))
				dright = 2 * spd
			elif (blockdefense(self.x,2,self.y,self.x+spd,self.y)):
				window.blit(end_right, (self.x+spd, self.y))
				dright = spd
			if (blockdefense(self.x,1,self.y,self.x,self.y-2*spd) and blockdefense(self.x,2,self.y,self.x,self.y - spd)):
				window.blit(default_up,(self.x, self.y-spd))
				window.blit(end_up,(self.x, self.y-2*spd))
				dup = 2 * spd
			elif (blockdefense(self.x,1,self.y,self.x,self.y-spd)):
				window.blit(end_up,(self.x, self.y-spd))
				dup = spd
			if (blockdefense(self.x,1,self.y,self.x,self.y+2*spd) and blockdefense(self.x,1,self.y,self.x,self.y+spd)):
				window.blit(default_down,(self.x, self.y+spd))
				window.blit(end_down,(self.x, self.y+2*spd))
				ddown = 2 * spd
			elif (blockdefense(self.x,1,self.y,self.x,self.y+spd)):
				window.blit(end_down,(self.x, self.y+spd))
				ddown = spd
			for enem in enemys:
				enemydo = True
				temps = False
				boomokay = False
				if (x == enem.x) and (y == enem.y):
					#died = True
					global hp
					hp -= 4
				if (enem.x == self.x) and (enem.y == self.y):
					boomokay = True
				if (enem.x == self.x) and (abs(self.y - enem.y) <= dup):
					boomokay = True
				if (enem.x == self.x) and (abs(enem.y - self.y) <= ddown):
					boomokay = True
				if (enem.y == self.y) and (abs(self.x - enem.x) <= dleft):
					boomokay = True
				if (enem.y == self.y) and (abs(enem.x - self.x) <= dright):
					boomokay = True
				if boomokay:
					if (enem.hp <= 0):
						enemys.pop(enemys.index(enem))
						kills += 1
					else:
						enem.hp -= 6
						enemylive -= 1
				if (kills == enemymax):
					print('u win')
					game = 0
					win = 1
			for iceblock in ice:
				if (((abs(iceblock.x - self.x) <= 80) and (iceblock.y == self.y) or ((iceblock.x == self.x) and (abs(iceblock.y - self.y)<= 80)))):
					temp = random.randint(0,9)
					print("temp:",temp)
					if (temp == 8):
						bonusarr.append(bonus((iceblock.x),(iceblock.y),(1)))
					if (temp == 9):
						bonusarr.append(bonus((iceblock.x),(iceblock.y),(2)))			
					ice.pop(ice.index(iceblock))
			if not((abs(self.y - y) <= dup) and (self.x == x)) and not((abs(y - self.y) <= ddown) and (self.x == x)) and not((abs(self.x - x) <= dleft) and (self.y == y)) and not((abs(x - self.x) <= dright) and (self.y == y)):
				print("normal")
			else:
				if not((abs(self.y - y) <= dup) and (self.x == x)):
					print("up")
				if not((abs(y - self.y) <= ddown) and (self.x == x)):
					print("down")
				if not((abs(self.x - x) <= dleft) and (self.y == y)):
					print("left")
				if not((abs(x - self.x) <= dright) and (self.y == y)):
					print("right")
				print("down:",ddown)
				if (hp >= 1):
					hp -= 2
		else:
			bombs.pop(bombs.index(self))
			
class bullet():
	def __init__(self,x,y,direction):
		self.x = x
		self.y = y
		self.direction = direction
	def draw(self,window):	
		window.blit(skillicon[1],(self.x ,self.y))				
class bonus():
	def __init__(self,x,y,bonustype):
		self.x = x
		self.y = y
		self.bonustype = bonustype
		self.cooldown = 3000
	def draw(self, window):
		if (self.bonustype == 1):
			window.blit(bonusdraw,(self.x, self.y))
		if (self.bonustype == 2):
			window.blit(bonusdraw1,(self.x, self.y))
class buff():
	def __init__(self,bonustype,cooldown, rangex):
		self.bonustype = bonustype
		self.cooldown = cooldown
		self.rangex = rangex
		self.last = pygame.time.get_ticks()
		self.end = False

	def use(self):
		if (now - self.last >= self.cooldown):
			now = pygame.time.get_ticks()
			self.end = True
			if (bonustype == 1):
				spd = 20
			elif (bonustype == 2):
				antidie = False
	def dobuff(self,bonustype):
		global spd
		global antidie
		if (bonustype == 1):
			spd = 40
		elif (bonustype == 2):
			antidie == True
			
skills.append(skill(680,40,1000,0))
skills.append(skill(680,120,400,1))
def diedly():
	global died
	died = True
def checkf():
	flajok = 1
	for bomb in bombs:
			if (bomb.x == x) and (bomb.y == y):
				flajok = 0
	return flajok
def buff(typebuff):
	if (typebuff == 1):
		buffs.append(buff(1),(10000), (0))
	if (typebuff == 2):
		buffs.append(buff(2),(5000), (0))
def wavebomb(ax1,ay1):
	global ax
	global ay
def blockdefense(x,typex,y, kx, ky):
	#if (typex == 1) and (x % 80 == 50):
	#	ret = 0
	#elif (typex == 2) and (x % 80 == 10) and (y % 80 == 50):
	#	ret = 0
	#else:
	ret = 1
	for wallz in wall:
		if (wallz.x == kx) and (wallz.y == ky):
			ret = 0
	for blockd in ice:
		if (blockd.x == kx) and (blockd.y == ky):
			ret = 0
	return ret
def regenerate_function():
	global mp
	if (mp < 10):
		if (mp + 0.1 > 10):
			mp = 10
		else:	
			mp += 0.1			 
def drawnupdate(ax,ay):
	global AnimCount
	global hp
	global boombombtime
	global actbomb
	global drawbomb
	global x1
	global y1
	global right
	global left
	global up
	global down
	global died
	y1 = 50
	#blockdraw()
	window.fill((45,45,45))
	int_font = pygame.font.SysFont('Verdana',12)
	text1 = int_font.render("Здоровье:" , 1, (255,0,0))
	text2 = int_font.render("Энергия: ", 1, (0,0,255))
	window.blit(text1, (0,660))
	window.blit(text2, (0,675))
	window.blit(background,(0,0))
	if (hp > 0):
		if (hp >= 7):
			pygame.draw.rect(window, GREEN, (70, 664, round(59*hp),10))
		elif (hp >= 4):
			pygame.draw.rect(window, YELLOW, (70, 664, round(59*hp),10))
		elif (hp >= 1):
			pygame.draw.rect(window, RED, (70, 664, round(59*hp),10))
	if (mp > 0):
		if (mp >= 4):
			pygame.draw.rect(window, BLUE, (70, 679, round(59*mp),10))
		elif (mp >= 1):
			pygame.draw.rect(window, LIGHT_BLUE, (70, 679, round(59*mp),10))
	window.blit(gran,(0,0))
	#for k in range(1,9):
	#	x1 = 50
	#	for i in range(1,9):
	#		window.blit(block[0], (x1,y1))
	#		#window.blit(block[0], camera.apply(e))
	#		x1 += 80
	#	y1 += 80
#		print(x1, y1)
#	print("drawbomb: ",drawbomb)
#	print("actbomb: ", actbomb)
#	boombombtime = 0
	if (drawbomb == True):
		if (actbomb == False):
			window.blit(bomba[0], (ax, ay))
#		pygame.draw.rect(window, (0,0,255),(ax,ay,width,height))
		elif (boombombtime >= 0) and (boombombtime <= 27):
			window.blit(bomba[1],(ax, ay))	
		elif (boombombtime >= 28) and (boombombtime <= 52):
			window.blit(bomba[2],(ax, ay))
		elif (boombombtime >= 53) and (boombombtime <= 60):
			window.blit(bomba[3],(ax, ay))
			window.blit(laser[0],(ax-80, ay-80))
			print(ax, ay, x, y)
			print("died : ",died)
		actbomb = True
	if (boombombtime < 60) and (actbomb == True):
		boombombtime += 1
		print(boombombtime)
	if (boombombtime == 60) and (actbomb == True):
		wavebomb(ax,ay)
		maxdrawbomb = 0
		boombombtime = 0
		actbomb = False
		drawbomb = False
		print(drawbomb)
	if AnimCount +1 >= 30:
		AnimCount = 0 
	for playerz in players:
		if left:
			window.blit(walkleft[0],(x, y))
#			pygame.draw.rect(window, (0,0,255),(x,y,width,height))
			AnimCount += 1
		elif right:
			window.blit(walkright[0],(x, y))
#			pygame.draw.rect(window, (0,0,255),(x,y,width,height))		
			AnimCount += 1
		elif up:
			window.blit(walkup[0],(x, y))
#			pygame.draw.rect(window, (0,0,255),(x,y,width,height))
			AnimCount += 1
		elif down:
#			pygame.draw.rect(window, (0,0,255),(x,y,width,height))
			window.blit(walkdown[0],(x, y))
			AnimCount += 1
		else:
			if (positionbool == 'right'):
				window.blit(walkright[0],(x, y))
			elif (positionbool == 'left'):
				window.blit(walkleft[0],(x, y))
			elif (positionbool == 'up'):
				window.blit(walkup[0],(x, y))
			elif (positionbool == 'down'):
				window.blit(walkdown[0],(x, y))
#		window.blit(nowalk[0],(x, y))
#		pygame.draw.rect(window, (0,0,255),(x,y,width,height))
	#30 FPS //например, 5 при 6 спрайтах
	for bulletz in bullets:
		if (direction == 'up') and not(blockdefense(bulletz.x,1,bulletz.y,bulletz.x,bulletz.y-20)):
			bullets.pop(bullets.index(bulletz))
		elif (direction == 'down') and not(blockdefense(bulletz.x,1,bulletz.y,bulletz.x,bulletz.y+20)):
			bullets.pop(bullets.index(bulletz))
		elif (direction == 'left') and not(blockdefense(bulletz.x,2,bulletz.y,bulletz.x-20,bulletz.y)):
			bullets.pop(bullets.index(bulletz))
		elif (direction == 'right') and not(blockdefense(bulletz.x,2,bulletz.y,bulletz.x+20,bulletz.y)):
			bullets.pop(bullets.index(bulletz))
		elif (bulletz.y < 10) + (bulletz.y > 610) + (bulletz.x < 10) + (bulletz.x > 610):
			bullets.pop(bullets.index(bulletz))
		else:
			bulletz.draw(window)
	for wallz in wall:
		wallz.draw(window, 1)
	for playerz in players:
		playerz.draw(window)
	for skillz in skills:
		skillz.draw(window, lastz)
	for iceblock in ice:
		if (died == False):
			iceblock.draw(window, 2)
	for bonuz in bonusarr:
		if (died == False):
			bonuz.draw(window)
#			pygame.display.update()
	for enem in enemys:
#		отрисовка мобов в окне
		if (died == False):
			enem.draw(window)
	for bomb in bombs:
		if (died == False):
			bomb.draw(window)
#			pygame.display.update()
#	window.fill((0,0,0))
#	pygame.draw.rect(window, (0,0,255),(x,y,width,height))
#	drawdie(died)
	if (died == True):
		window.blit(gameover, (0,0))
def draw_menu():
	global menu
	global level_choice
	global wait
	global game
	while menu:
		pygame.time.delay(100)
		int_font = pygame.font.SysFont('Verdana',24)
		mousex, mousey = pygame.mouse.get_pos()	
		window.blit(bg_menu, (0,0))
		window.blit(button, ((maxw+120)/2-100,(maxh+40)/2 - 120))
		window.blit(button, ((maxw+120)/2-100,(maxh+40)/2 - 60))
		window.blit(button, ((maxw+120)/2-100,(maxh+40)/2))
		window.blit(button, ((maxw+120)/2-100,(maxh+40)/2 + 60))
		menu_button_1 = int_font.render("Играть" , 1, (255,0,0))
		menu_button_2 = int_font.render("Управление", 1, (0,0,255))
		menu_button_3 = int_font.render("Pro режим", 1, (0,255, 0))
		menu_button_4 = int_font.render("Выйти ", 1, (0,255,255))
		window.blit(menu_button_1, ((maxw+120)/2 - 100+ 60, (maxh+40)/2 - 120))
		window.blit(menu_button_2, ((maxw+120)/2 - 100+ 30, (maxh+40)/2 - 60))
		window.blit(menu_button_3, ((maxw+120)/2 - 100+ 40, (maxh+40)/2))
		window.blit(menu_button_4, ((maxw+120)/2 - 100+ 60, (maxh+40)/2 + 60))
		for event in pygame.event.get():
			if (event.type == pygame.QUIT):
				exit()
			if event.type == pygame.MOUSEBUTTONDOWN:
				#pass
				mousex, mousey = pygame.mouse.get_pos()
				if (event.type == 5) and (mousex > 290) and (mousex <= 490) and (mousey > 230) and(mousey <= 270):
					#game = 1
					menu = 0
					if (event.type == pygame.MOUSEBUTTONDOWN):
						level_choice = 1
					#import time
					#time.sleep(1)
				elif (event.type == 5) and (mousex > 290) and (mousex <= 490) and (mousey > 410) and (mousey <= 450):
					sys.exit()
				elif (event.type == 5) and (mousex > 290) and (mousex <= 490) and (mousey > 290) and (mousey <= 330):
					webbrowser.open("http://bombermania.github.io/FAQ")
					pass
				elif (event.type == 5) and (mousex > 290) and (mousex <= 490) and (mousey > 350) and (mousey <= 390):
					if pros:
						os.system("pro.py")
						pros = False
					pros = True
				else:
					print(mousex, mousey)
		if (mousex > 290) and (mousex <= 490) and (mousey > 230) and(mousey <= 270):
			window.blit(button_on_click, ((maxw+120)/2 - 100, (maxh+40)/2 - 120))
			window.blit(menu_button_1, ((maxw+120)/2 - 100+ 60, (maxh+40)/2 - 120))
		if (mousex > 290) and (mousex <= 490) and (mousey > 290) and (mousey <= 330):
			window.blit(button_on_click, ((maxw+120)/2 - 100, (maxh+40)/2 - 60))
			window.blit(menu_button_2, ((maxw+120)/2 - 100+ 30, (maxh+40)/2 - 60))	
		if (mousex > 290) and (mousex <= 490) and (mousey > 350) and (mousey <= 390):
			window.blit(button_on_click, ((maxw+120)/2 - 100, (maxh+40)/2))
			window.blit(menu_button_3, ((maxw+120)/2 - 100 + 40, (maxh+40)/2 ))	
		if (mousex > 290) and (mousex <= 490) and (mousey > 410) and (mousey <= 450):
			window.blit(button_on_click, ((maxw+120)/2 - 100, (maxh+40)/2 + 60))
			window.blit(menu_button_4, ((maxw+120)/2 - 100 + 60, (maxh+40)/2 +60))	
		info = 'bomberman v0.9: Menu ' + str(mousex) + ' ' + str(mousey)
		pygame.display.set_caption(info)
		pygame.display.flip()	
		#pygame.display.update()
	#gener_ice_blocks()
def level_choices():
	global game
	global level_choice
	global menu
	global wait
	global gener
	global levelz
	while level_choice:
		levels_completed = []
		check_completed = open('Data/Levels/completed.lvl').read().split('\n')[0]
		for i in range(0,20):
			temp = int(check_completed.split()[i])
			levels_completed.append(temp)
		#print("a: ",levels_completed)
		window.blit(brick_menu, (0,0))
		pygame.time.delay(100)
		int_font = pygame.font.SysFont('Verdana',42)
		mousex, mousey = pygame.mouse.get_pos()
		info = 'Choose a level:'
		tempx = 40
		tempy = 40
		z = 0
		level_num = 1
		#print("len", len(levels_completed))
		for j in range(0,4):
			for i in range(0,3):
				window.blit(lvlicon[z], (tempx, tempy))
				if (levels_completed[j*5+(i)] == 1):
					window.blit(galochka, (tempx, tempy-5 ))
				menu_button_1 = int_font.render(str(level_num), 1, (255,0,0))
				window.blit(menu_button_1, (tempx +10, tempy +10))
				level_num += 1
				tempx += 160
			for k in range(0,2):
				window.blit(lvlicon[z+1], (tempx, tempy))
				if (levels_completed[j*5+3+(k)] == 1):
					window.blit(galochka, (tempx, tempy-5 ))
				menu_button_1 = int_font.render(str(level_num), 1, (255,0,0))
				window.blit(menu_button_1, (tempx +10, tempy +10))
				tempx += 160
				level_num += 1
			z += 2
			tempy += 160
			tempx = 40
		for event in pygame.event.get():
			if event.type == pygame.MOUSEBUTTONDOWN:
				mousex, mousey = pygame.mouse.get_pos()
				tempx = 40
				tempy = 40
				for j in range(0,4):
					for i in range(0,5):
						if (mousex > tempx) and (mousex < tempx+80) and (mousey > tempy) and (mousey < tempy+80):
							#game = 1
							menu = 0
							levelz = j * 5 + (i+1)
							print("levelz: ", levelz)
							wait = 1
							gener = True
							level_choice = 0
							#import time
							#time.sleep(0.5)
							break
						tempx += 160			
					tempx = 40
					tempy += 160
				'''	if (event.type == 5) and (mousex > 290) and (mousex <= 490) and (mousey > 230) and(mousey <= 270):
						#game = 1
						menu = 0
						level_choice = 1
					elif (event.type == 5) and (mousex > 290) and (mousex <= 490) and (mousey > 410) and (mousey <= 450):
						sys.exit()
					elif (event.type == 5) and (mousex > 290) and (mousex <= 490) and (mousey > 290) and (mousey <= 330):
						webbrowser.open("http://bombermania.github.io/FAQ")
						pass
					elif (event.type == 5) and (mousex > 290) and (mousex <= 490) and (mousey > 350) and (mousey <= 390):
						if pros:
							os.system("pro.py")
							pros = False
						pros = True
					else:
						print(mousex, mousey)
				'''
					
			pygame.display.set_caption(info)
			for event in pygame.event.get():
				if (event.type == pygame.QUIT):
					exit()
			'''	if event.type == pygame.MOUSEBUTTONDOWN:
					#pass
					mousex, mousey = pygame.mouse.get_pos()
					if (event.type == 5) and (mousex > 290) and (mousex <= 490) and (mousey > 230) and(mousey <= 270):
						#game = 1
						menu = 0
						level_choice = 1
					elif (event.type == 5) and (mousex > 290) and (mousex <= 490) and (mousey > 410) and (mousey <= 450):
						sys.exit()
					elif (event.type == 5) and (mousex > 290) and (mousex <= 490) and (mousey > 290) and (mousey <= 330):
						webbrowser.open("http://bombermania.github.io/FAQ")
						pass
					elif (event.type == 5) and (mousex > 290) and (mousex <= 490) and (mousey > 350) and (mousey <= 390):
						if pros:
							os.system("pro.py")
							pros = False
						pros = True
					else:
						print(mousex, mousey)
			'''
			
			pygame.display.flip()
def draw_win():
	global win
	global menu
	while win:
		pygame.time.delay(100)
		pygame.font.init()
		window.blit(bg_menu, (0,0))
		int_font = pygame.font.SysFont('Verdana',24)
		mousex, mousey = pygame.mouse.get_pos()	
		window.blit(button, ((maxw+120)/2-100,(maxh+40)/2 - 120))
		menu_button_1 = int_font.render("Меню" , 1, (255,0,0))
		int_font_temp = pygame.font.SysFont('Verdana',32)
		win_text = int_font_temp.render("Победа!" , 1, (0,255,0))
		window.blit(menu_button_1, ((maxw+120)/2 - 100+ 60, (maxh+40)/2 - 120))
		window.blit(win_text, ((maxw+120)/2-50, (maxh+40)/2-200))
		for event in pygame.event.get():
			mousex, mousey = pygame.mouse.get_pos()
			if (event.type == pygame.QUIT):
				exit()
			if event.type == pygame.MOUSEBUTTONDOWN:
				if (event.type == 5) and (mousex > 290) and (mousex <= 490) and (mousey > 230) and(mousey <= 270):
					#game = 1
					menu = 1
					win = 0
		if (mousex > 290) and (mousex <= 490) and (mousey > 230) and(mousey <= 270):
			window.blit(button_on_click, ((maxw+120)/2 - 100, (maxh+40)/2 - 120))
			window.blit(menu_button_1, ((maxw+120)/2 - 100+ 60, (maxh+40)/2 - 120))
		pygame.display.flip()

def waits():
	global c
	global kills
	global game
	global wait
	while wait: 
		for event in pygame.event.get():
			if event.type == pygame.MOUSEBUTTONDOWN:
				c = 2
		game = 1
		kills = 0
		wait = 0
'''Отвечает за генерацию уровня, разработка v1.0'''
def generation_level():
	global typelvl
	global levelh
	global levelw
	global icemax
	global menu
	global gener
	global levelz
	global level_choice
	if (typelvl == 'Random'):
		levelh = int(open('Data/data.txt').read().split('\n')[0]) // 40 
		levelw = int(open('Data/data.txt').read().split('\n')[2]) // 40
		icemax = int(open('Data/data.txt').read().split('\n')[4])
		enemymax = int(open('Data/data.txt').read().split('\n')[6])
		print(levelh, levelw, icemax)
	#1 - кирпичи
	#2 - лед
	#0 - свободно
	#генерация
		for i in range(0,levelh):
			level.append([])
			for k in range(0,levelw):
	#			if (k == 0) or (k == levelw-1) or (i == 0) or (i == levelh-1): # + (k == levelh-1)):
	#				level[i].append(1)
				if ((k+1) % 2 == 0 and (i+1) % 2 == 0) and not(k == levelw-1 or i == levelh-1):			
					level[i].append(1)
					wall.append(blocked((10+k*40),(10+i*40)))
			#elif((icemax > 0) and (i + k != 0 and i + k > 2)):
			#	temp = random.randint(0,10)
			#	if (temp >= 8):
			#		level[i].append(2)
			#		ice.append(blocked((10+k*40),(10+i*40)))
			#		icemax -=1
				else:
					level[i].append(0)
		while (icemax > 0):
			for i in range(0,levelh):
				for j in range(0,levelw):
					temp = random.randint(0,100)
					if (temp >= 95) and (level[i][j] == 0) and(level[i][j] == 0) and not(j == levelw-1 or i == levelh-1):
						level[i][j] = 2
						ice.append(blocked((10+j*40), (10+i*40)))
						icemax -= 1
				print(level[i])
	#print(level)
		print("levelh: ", levelh)
		print("levelw: ", levelw)
		gener = False
	else:
		for i in range(0,16):
			level.append([])
			tmp = str(open(str('Data/Levels/'+ str(levelz) + '.lvl')).read().split('\n')[i])
			print("tmp:", tmp)
			for k in range(0,16):
				temp = int(tmp.split()[k])
				if (temp == 1):
					wall.append(blocked((10+k*40),(10+i*40)))
				if (temp == 2):
					ice.append(blocked((10+k*40), (10+i*40)))
				level[i].append(temp)
			print(level[i])
		tmp = int(open(str('Data/Levels/' + str(levelz) + '.lvl' )).read().split('\n')[16])
		enemymax = tmp
		gener = False
while True:
	if menu:
		draw_menu()
	if level_choice:
		level_choices()
	if (gener):
		level = []
		brick = []
		wall = []
		generation_level()
	if wait:
		waits()
	if win:
		game = 0
		draw_win()
	if game:
		pygame.time.delay(30)
	#	clock.tick(15)
		for event in pygame.event.get():
			if (event.type == pygame.QUIT):
				exit()
#	for bombs in maxbombs:
#		if bombs.x 
		keys = pygame.key.get_pressed()
		if keys[pygame.K_LEFT] and (x > 10) and (died == False) and (blockdefense(x,2,y,x-spd,y) and left == False):
#		z = blockdefense(x,2,y)
#		if (z and left == False):
			x -= spd
			for playerz in players:
				playerz.x -= spd
			left = True
			right = False
			down = False
			up = False
			direction = 'left'
		elif keys[pygame.K_RIGHT] and (x < (maxw - width) - 10) and (died == False) and (blockdefense(x,2,y,x+spd,y) and right == False):
#		z = blockdefense(x,2,y)
#		if (z and right == False):
			x += spd
			for playerz in players:
				playerz.x += spd
			left = False
			up = False
			down = False
			right = True
			direction = 'right'
		elif keys[pygame.K_UP] and (y > 10) and (died == False) and (blockdefense(x,1,y,x,y-spd) and up == False):
#		z = blockdefense(x,1,y)
#		if (z and up == False):
			y -= spd
			for playerz in players:
				playerz.y -= spd
			up = True
			down = False
			right = False
			left = False
			direction = 'up' 
		elif keys[pygame.K_DOWN] and (y < (maxh - height) - 10) and (died == False) and (blockdefense(x,1,y,x,y+spd) and down == False):
#		z = blockdefense(x,1,y)
#		if (z and down == False):
			y += spd
			for playerz in players:
				playerz.y += spd
			down = True
			up = False
			right = False
			left = False
			direction = 'down'
#			pass
		elif keys[pygame.K_f] and checkf() and bombcooldown:
#		if (currentbomb < maxbomb):
#		bomb(x,y)
			bombcooldown = False
			lastz = pygame.time.get_ticks()
			bombs.append(bomb((x),(y)))
#		bomb.boom()		
		elif keys[pygame.K_g] and bulletcooldown and (mp >= 2):
			bulletcooldown = False
			lastz = pygame.time.get_ticks()
			mp -= 2
			bullets.append(bullet((x),(y), (direction)))
		if (enemycount < enemymax):
			enemys.append(enemy((330),(330)))
#		enem.enemy_motion_cooldown()
			enemycount += 1	
			enemylive += 1
			print(drawbomb,ax,ay)
		else:
			if down:
				positionbool = 'down'
			elif up:
				positionbool = 'up'
			elif left:
				positionbool = 'left'
			elif right:
				positionbool = 'right'
			down = False
			up = False
			right = False
			left = False
			AnimCount = 0
		for bulletz in bullets:
			if (bulletz.direction == 'up'):
				bulletz.y -= 20
			elif (bulletz.direction == 'down'):
				bulletz.y += 20
			elif (bulletz.direction == 'left'):
				bulletz.x -= 20
			elif (bulletz.direction == 'right'):
				bulletz.x += 20
		for bonuz in bonusarr:
			if (bonuz.x == x) and (bonuz.y == y):
				bonusarr.pop(bonusarr.index(bonuz))
		for enem in enemys:
			enemydo = True
			if (x == enem.x) and (y == enem.y):
				hp -= 2
			if (boombombtime >= 53) and (boombombtime <= 60) and (((abs(ax - enem.x) <= 80)) and (ay == enem.y) or ((ax == enem.x) and (abs(ay - enem.y)<=80))):
				enemys.pop(enemys.index(enem))
				enemylive -= 1
			#работа интеллекта мобов
			if not (enem.enemy_motion_cooldown()):
				continue
			while(enemydo == True):
				enemyneed = enemyskills[random.randint(0,3)]
				if (enemyneed == 'right') or (enemyneed == 'left'):
					if (enemyneed == 'right') and (enem.x < (maxw - width) - 10) and (died == False) and (enem.coolbool == True) and (blockdefense(enem.x,2,enem.y,enem.x+spd,enem.y)):
						enem.x += spd	
						enem.motion = 'right'
						enem.coolbool = False
	#					enem.enemy_motion_cooldown()
						enemydo = False
						break
					elif (enemyneed == 'left') and (enem.x > 10) and  not died  and enem.coolbool and (blockdefense(enem.x,2,enem.y,enem.x-spd,enem.y)):
						enem.x -= spd
						enem.motion = 'left'
						enem.coolbool = False
	#					enem.enemy_motion_cooldown()
						enemydo = False
						break
					else:
						break
				elif (enemyneed == 'up') or (enemyneed == 'down'):	
					if (enemyneed == 'up') and (enem.y > 10) and (died == False) and (enem.coolbool == True) and (blockdefense(enem.x,1,enem.y,enem.x,enem.y-spd)):
						enem.y -= spd
						enem.motion = 'up'
						enem.coolbool = False
						enem.enemy_motion_cooldown()
						enemydo = False
						break
					elif (enemyneed == 'down') and (enem.y < (maxh - height) - 10) and (died == False) and (enem.coolbool == True) and (blockdefense(enem.x,1,enem.y,enem.x,enem.y+spd)): 	
						enem.y += spd
						enem.motion = 'down'
						enemydo = False
						enem.coolbool= False
						enem.enemy_motion_cooldown()
						break
					else:
						break
		regenerate_function()
		info = 'bomberman v0.9.1: ' + str(x) + ':' + str(y)
		pygame.display.set_caption(info)
	#	for playerz in players:
	#		hero = Player(playerz.x,playerz.y) 
	#	for playerz in players:
	#		hero = Player(playerz.x, playerz.y)
		#hero.update()
	#	camera.update(hero)
		
	#	start_menu()
		if (hp <= 0):
			#os.system("a.py")
			diedly()
		drawnupdate(ax,ay)
		pygame.display.flip()	
pygame.quit()
