## -*- coding: utf-8 -*-
from tkinter import *
from tkinter import messagebox
 
 
def display_full_name():
	global pros
	#messagebox.showinfo("Bomber pro mode", name.get() + " " + surname.get())
	levelh = levelh1.get()
	levelw = levelw1.get()
	icemax = icemax1.get()
	open('Data/data.txt', 'w').close()
	f = open('Data/data.txt', 'w')
	f.write(str(levelh) + '\n')
	f.write('\\levelh' + '\n')
	f.write(str(levelw) + '\n')
	f.write('\\levlw' + '\n')
	f.write(str(icemax) + '\n')
	f.write('\\icemax' + '\n')
	pros = True
	root.quit()
root = Tk()
root.geometry("300x250")
root.title("Введите данные для уровня")
levelh1 = StringVar()
levelw1 = StringVar()
icemax1 = StringVar()
 
levelh1_label = Label(text="Высота уровня (кратная 40):")
levelw1_label = Label(text="Ширина уровня (кратная 40):")
icemax1_label = Label(text="Количество блоков льда :")

levelh1_label.grid(row=0, column=0, sticky="w")
levelw1_label.grid(row=1, column=0, sticky="w")
icemax1_label.grid(row=2, column=0, sticky="w")
 
levelh1_entry = Entry(textvariable=levelh1)
levelw1_entry = Entry(textvariable=levelw1)
icemax1_entry = Entry(textvariable=icemax1)

levelh1_entry.grid(row=0,column=1, padx=5, pady=5)
levelw1_entry.grid(row=1,column=1, padx=5, pady=5)
icemax1_entry.grid(row=2,column=1, padx=5, pady=5)
 
 
message_button = Button(text="Подтвердить", command=display_full_name)
message_button.grid(row=3,column=1, padx=5, pady=5, sticky="e")
 
root.mainloop()
