import pygame
import math
from tkinter import *
pygame.init()
maxw = 660
maxh = 660
#640/40 = 16 / 2 = 8 движений в одну сторону максимально
maxbomb = []
#########################################################
# отвечает за сам процесс, желательно не трогать ВООБЩЕ!
global game
game = 1
#########################################################
window = pygame.display.set_mode((maxw, maxh))
gran = pygame.image.load('images/gran.png')
background = pygame.image.load('images/background.png')
walkright = [pygame.image.load('images/bomberman.png')]
walkleft = [pygame.image.load('images/bomberman.png')]
walkup = [pygame.image.load('images/bomberman.png')]
walkdown = [pygame.image.load('images/bomberman.png')]
nowalk = [pygame.image.load('images/bomberman.png')]
laser = [pygame.image.load('images/boom.png')]
block = [pygame.image.load('images/block.png')]
bomb = [pygame.image.load('images/bomb0.png'), pygame.image.load('images/bomb1.png'), pygame.image.load('images/bomb2.png'), pygame.image.load('images/bomb3.png')]
##########################################################
# Персонаж
global x
global y
x = 10
y = 10
width = 40
height = 40
spd = 40
##########################################################
#Работа бомбы
global ax
global ay
global drawbomb
global boombombtime
global actbomb

ax = 0
ay = 0
boombombtime = 0
actbomb = False
##########################################################
# Стены
global x1
global y1
##########################################################
#Враги
#enemyz = []
#killed = 0
#spen = 0
##########################################################
AnimCount = 0
maxbomb = 3
maxdrawbomb = 0
currentbomb = 0
checkbomb = 0
clock = pygame.time.Clock()
drawbomb = False
left = False
right = False
up = False
down = False
###########################################################
#class bomb():
#	def __init__(self,x,y):
#		self.x = x
#		self.y = y
#	def draw(self, window):
#		pygame.draw.circle(window, (self.x,self.x))

#def bomb(x,y):
#	global drawbomb
#	global ax
#	global ay
#	drawbomb = True
#	ax = x
#	ay = y
#######
#Стартовый ввод
encount = int(input())
notkilled = encount
#######
#def end():
#	root = Tk()
#	root.title("Game Over")
#	root.geometry("350x250")
#	btn = Button(text="Ok",          	# текст кнопки 
#             background="#00BFFF",  # фоновый цвет кнопки
#             foreground="#ffffff",     # цвет текста
#             padx="31",             # отступ от границ до содержимого по горизонтали
#             pady="5",              # отступ от границ до содержимого по вертикали
#             font="10",             # высота шрифта
#             command = wavebomb(1,1)
#             )
#	btn.pack()
#	root.mainloop()
def wavebomb(ax1,ay1):
	global ax
	global ay	
def blockdefense(x,typex,y):
	if (typex == 1) and (x % 80 == 50):
		return 0
	elif (typex == 2) and (x % 80 == 10) and (y % 80 == 50):
		return 0
	else:
		return 1
########################################################
#Прорисовка врага
#class enemy():
#	def __init__(self, ex,ey):
#		self.ex = ex
#		self.ey = ey
#	def draw(self, window):
#		pygame.draw.circle(window, (self.ex, self.ey), 5)
#	def run():
#		pass
########################################################		 
def drawnupdate(ax,ay):
	global AnimCount
	global boombombtime
	global actbomb
	global drawbomb
	global x1
	global y1
	y1 = 50
	#blockdraw()
	window.blit(background,(0,0))
	window.blit(gran,(0,0))
	for k in range(1,9):
		x1 = 50
		for i in range(1,9):
			window.blit(block[0], (x1,y1))
			x1 += 80
		y1 += 80
#		print(x1, y1)
#	print("drawbomb: ",drawbomb)
#	print("actbomb: ", actbomb)
#	boombombtime = 0
	if (drawbomb == True):
		if (actbomb == False):
			window.blit(bomb[0], (ax, ay))
#		pygame.draw.rect(window, (0,0,255),(ax,ay,width,height))
		elif (boombombtime >= 0) and (boombombtime <= 27):
			window.blit(bomb[1],(ax, ay))	
		elif (boombombtime >= 28) and (boombombtime <= 52):
			window.blit(bomb[2],(ax, ay))
		elif (boombombtime >= 53) and (boombombtime <= 60):
			window.blit(bomb[3],(ax, ay))
			window.blit(laser[0],(ax-80, ay-80))
# 			это нужно сократить как можно быстрее, набросок
			print(ax, ay, x, y)	
			if (((abs(ax - x) <= 80)) and (ay == y) or ((ax == x) and (abs(ay - y)<=80))):
				global game
				game = 0
				pass
		actbomb = True
	if (boombombtime < 60) and (actbomb == True):
		boombombtime += 1
		print(boombombtime)
	if (boombombtime == 60) and (actbomb == True):
		wavebomb(ax,ay)
		maxdrawbomb = 0
		boombombtime = 0
		actbomb = False
		drawbomb = False
		print(drawbomb)
	if AnimCount +1 >= 30:
		AnimCount = 0 
	if left:
#		window.blit(walkleft[0],(x, y))
		pygame.draw.rect(window, (0,0,255),(x,y,width,height))
		AnimCount += 1
	elif right:
#		window.blit(walkright[0],(x, y))
		pygame.draw.rect(window, (0,0,255),(x,y,width,height))		
		AnimCount += 1
	elif up:
#		window.blit(walkup[0],(x, y))
		pygame.draw.rect(window, (0,0,255),(x,y,width,height))
		AnimCount += 1
	elif down:
		pygame.draw.rect(window, (0,0,255),(x,y,width,height))
#		window.blit(walkdown[0],(x, y))
		AnimCount += 1
	else:
#		window.blit(nowalk[0],(x, y))
		pygame.draw.rect(window, (0,0,255),(x,y,width,height))
	#30 FPS // 5 при 6 спрайтах

#	window.fill((0,0,0))
#	pygame.draw.rect(window, (0,0,255),(x,y,width,height))	
	pygame.display.update()

while game:
#	pygame.time.delay(30)
	clock.tick(15)
	for event in pygame.event.get():
		if (event.type == pygame.QUIT):
			exit()	
#	for bombs in maxbombs:
#		if bombs.x 
#	if (spen >= 1):
#		for enemys in enemyz:
#			if actbomb:
#				if (abs(ax-enemys.x) <= 40) and (ay == enemys.y) or (abs(ay-enemys.y) <= 40) and (ax == enemys.x):
#					enemys.pop(enemy.index(enemys))
#					killed += 1
#					notkilled -= 1
#					if (killed != encount):
#						enemy.append(enemy(ex,ey))
#				else:
#					enemyrun()
			#удаление моба или он дальше движется
	keys = pygame.key.get_pressed()
	if keys[pygame.K_LEFT] and (x > 10):
		z = blockdefense(x,2,y)
		if (z and left == False):
			x -= spd
			left = True
			right = False
			down = False
			up = False
	elif keys[pygame.K_RIGHT] and (x < (maxw - width) - 10):
		z = blockdefense(x,2,y)
		if (z and right == False):
			x += spd
			left = False
			up = False
			down = False
			right = True
	elif keys[pygame.K_UP] and (y > 10):
		z = blockdefense(x,1,y)
		if (z and up == False):
			y -= spd
			up = True
			down = False
			right = False
			left = False 
	elif keys[pygame.K_DOWN] and (y < (maxh - height) - 10):
		z = blockdefense(x,1,y)
		if (z and down == False):
			y += spd
			down = True
			up = False
			right = False
			left = False
		else:
			pass
	elif keys[pygame.K_s]:
#		if (currentbomb < maxbomb):
#		bomb(x,y)
		if (drawbomb != True):
			drawbomb = True
			maxdrawbomb += 1
			ax = x
			ay = y
		print(drawbomb,ax,ay)
	else:
		down = False
		up = False
		right = False
		left = False
		AnimCount = 0
	print("drawnupdate: drawbomb:", drawbomb)
	drawnupdate(ax,ay)
	info = 'bomberman v0.3.2 ' + str(x) + ':' + str(y)
	pygame.display.set_caption(info)
	
		
pygame.quit()
