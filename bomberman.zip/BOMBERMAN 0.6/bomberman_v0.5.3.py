import pygame
import math
import random
from tkinter import *
pygame.init()
maxw = 660
maxh = 660
#640/40 = 16 / 2 = 8 движений в одну сторону максимально
maxbomb = []
#########################################################
# отвечает за сам процесс, желательно не трогать ВООБЩЕ!
global game
global hp
hp = 10
mp = 10
game = 1
#########################################################
window = pygame.display.set_mode((maxw+120, maxh+40))
gran = pygame.image.load('images/gran.png')
cursor = pygame.image.load(('images/system/cursor.png'))
background = pygame.image.load('images/backgrounds/bg.png')
gameover = pygame.image.load('images/backgrounds/gameover1.png')
walkright = [pygame.image.load('images/Hero/Right.png')]
walkleft = [pygame.image.load('images/Hero/Left.png')]
walkup = [pygame.image.load('images/Hero/Up.png')]
walkdown = [pygame.image.load('images/Hero/Down.png')]
nowalk = [pygame.image.load('images/Hero/Down.png')]
die = [pygame.image.load('images/Hero/Die.png')]
boom_start = pygame.image.load('images/Boom/boom_start.png')
default_down = pygame.image.load('images/Boom/default_down.png')
default_up = pygame.image.load('images/Boom/default_up.png')
default_left = pygame.image.load('images/Boom/default_left.png')
default_right = pygame.image.load('images/Boom/default_right.png')
end_up = pygame.image.load('images/Boom/end_up.png')
end_down = pygame.image.load('images/Boom/end_down.png')
end_left = pygame.image.load('images/Boom/end_left.png')
end_right = pygame.image.load('images/Boom/end_right.png')
bonusdraw = pygame.image.load('images/Bonus/bonus.png')
skillbad = pygame.image.load('images/Skills/bad_use.png')
skillgood = pygame.image.load('images/Skills/good_use.png')
skillfreeze = pygame.image.load('images/Skills/cant_use.png')
skillicon = [pygame.image.load('images/Skills/bomb.png')]
bonusdraw1 = pygame.image.load('images/Bonus/bonus1.png')
block = [pygame.image.load('images/Blocks/block.png')]
ice_block = [pygame.image.load('images/Blocks/ice_block1.png')]
bomba = [pygame.image.load('images/bomb0.png'), pygame.image.load('images/bomb1.png'), pygame.image.load('images/bomb2.png'), pygame.image.load('images/bomb3.png')]
##########################################################
#Настройки в самой библиотечке
pygame.font.init()
int_font = pygame.font.SysFont('Verdana',12)
pygame.mouse.set_visible(False) 
##########################################################
#Кортежи, для цветов
RED = (255,0,0)
YELLOW = (255,255,0)
GREEN = (0,80,0)
BLUE = (0,0,255)
LIGHT_BLUE = (0,80,255)
##########################################################
# Персонаж
global x
global y
x = 10
y = 10
global spd
width = 40
height = 40
spd = 40
global died
global antidie 
antidie = False
died = False
##########################################################
#Работа бомбы
global ax
global ay
global drawbomb
global boombombtime
global actbomb
ax = 0
ay = 0
boombombtime = 0
actbomb = False
##########################################################
# Враги
global enemymax
global enemycount
enemys = []
enemydo = False
enemymax = 2
enemyskills = ['right', 'left', 'up', 'down']
enemyneed = ' '
enemycount = 0
global enemylive 
enemylive = 0
##########################################################
# Стены
global x1
global y1
ice = []
cx = 50
##########################################################
# Бонусы
bonusarr = []
buffs = []
##########################################################
# Навыки
skills = []
global lastz
lastz = pygame.time.get_ticks()
global bombcooldown
bombcooldown = True
##########################################################
AnimCount = 0
maxbomb = 5
maxdrawbomb = 0
currentbomb = 0
checkbomb = 0
bombs = []
clock = pygame.time.Clock()
drawbomb = False
global left
left = False
global right
right = False
global up
up = False
global down
down = False
positionbool = 'down'
###########################################################
class enemy():
	def __init__(self, x, y):
		self.x = x
		self.y = y
		self.hp = 10
		self.mp = 0
		self.last = pygame.time.get_ticks()
		self.cooldown = 300
		self.coolbool = True
	def draw(self, window):
#		pygame.draw.rect(window, (0,255,0),(self.x,self.y, width, height))
		window.blit(bomba[0], (self.x, self.y))
		if (self.hp >= 1):
			pygame.draw.rect(window, RED, (self.x, self.y-10, round(4*self.hp),5))
		#pygame.display.update()
	def enemy_motion_cooldown(self):
		now = pygame.time.get_ticks()
		if (now - self.last >= self.cooldown):
			self.last = now
			self.coolbool = True
			return True
		else:
			return False
class blocked():
	def __init__(self, x, y):
		self.x = x
		self.y = y
	def draw(self,window):
		window.blit(ice_block[0],(self.x, self.y))
class skill():
	def __init__(self, x, y, cooldown, skilltype):
		self.x = x
		self.y = y
		self.last = pygame.time.get_ticks()
		self.skilltype = skilltype
		self.cooldown = cooldown
	def draw(self,window):
		global lastz
		self.last = lastz
		now = pygame.time.get_ticks()
		if (self.skilltype == 0):
			if (now - self.last < self.cooldown):
				window.blit(skillbad, (self.x, self.y))
			else:
				window.blit(skillgood, (self.x, self.y))
				global bombcooldown
				bombcooldown = True
			window.blit(skillicon[0], (self.x, self.y))

class bomb():
	def __init__(self, x ,y):
		self.x = x
		self.y = y
		self.last = pygame.time.get_ticks()
		self.boomtime = 1000
		self.splash = True
		global died
	def boom(self):
		now = pygame.time.get_ticks()
		if (now - self.last >= self.cooldown):
			self.last = now
			self.splash = True
	def draw(self, window):
		dleft = 0
		dup = 0
		dright = 0
		ddown = 0
		now = pygame.time.get_ticks()
		if (now - self.last < 500):
			window.blit(bomba[0], (self.x, self.y))
		elif (now - self.last <= 900):
			window.blit(bomba[1], (self.x, self.y))
		elif (now - self.last <= 1600):
			window.blit(bomba[2], (self.x, self.y))	
		elif (now - self.last <= 2000):
			window.blit(boom_start,(self.x, self.y))
			if (blockdefense(self.x,2,self.y,self.x-2*spd,self.y)):
				dleft = 2 * spd
				window.blit(default_left,(self.x-spd, self.y))
				window.blit(end_left,(self.x-2*spd, self.y))
			elif (blockdefense(self.x,2,self.y,self.x-spd, self.y)):
				dleft = spd
				window.blit(end_left, (self.x-spd, self.y))
			if (blockdefense(self.x,2,self.y,self.x+2*spd,self.y)):
				window.blit(default_right,(self.x+spd, self.y))
				window.blit(end_right,(self.x+2*spd, self.y))
				dright = 2 * spd
			elif (blockdefense(self.x,2,self.y,self.x+spd,self.y)):
				window.blit(end_right, (self.x+spd, self.y))
				dright = spd
			if (blockdefense(self.x,1,self.y,self.x,self.y-2*spd)):
				window.blit(default_up,(self.x, self.y-spd))
				window.blit(end_up,(self.x, self.y-2*spd))
				dup = 2 * spd
			elif (blockdefense(self.x,1,self.y,self.x,self.y-spd)):
				window.blit(end_up,(self.x, self.y-spd))
				dup = spd
			if (blockdefense(self.x,1,self.y,self.x,self.y+2*spd)):
				window.blit(default_down,(self.x, self.y+spd))
				window.blit(end_down,(self.x, self.y+2*spd))
				ddown = 2 * spd
			elif (blockdefense(self.x,1,self.y,self.x,self.y+spd)):
				window.blit(end_down,(self.x, self.y+spd))
				ddown = spd
			for enem in enemys:
				enemydo = True
				temps = False
				boomokay = False
				if (x == enem.x) and (y == enem.y):
					died = True
				if (enem.x == self.x) and (enem.y == self.y):
					boomokay = True
				if (enem.x == self.x) and (abs(self.y - enem.y) <= dup):
					boomokay = True
				if (enem.x == self.x) and (abs(enem.y - self.y) <= ddown):
					boomokay = True
				if (enem.y == self.y) and (abs(self.x - enem.x) <= dleft):
					boomokay = True
				if (enem.y == self.y) and (abs(enem.x - self.x) <= dright):
					boomokay = True 
				if boomokay:
					if (enem.hp <= 0):
						enemys.pop(enemys.index(enem))
					else:
						enem.hp -= 5
					global enemylive
					enemylive -= 1
			for iceblock in ice:
				if (((abs(iceblock.x - self.x) <= 80) and (iceblock.y == self.y) or ((iceblock.x == self.x) and (abs(iceblock.y - self.y)<= 80)))):
					temp = random.randint(0,9)
					print("temp:",temp)
					if (temp == 8):
						bonusarr.append(bonus((iceblock.x),(iceblock.y),(1)))
					if (temp == 9):
						bonusarr.append(bonus((iceblock.x),(iceblock.y),(2)))			
					ice.pop(ice.index(iceblock))
			if not((abs(self.y - y) <= dup) and (self.x == x)) and not((abs(y - self.y) <= ddown) and (self.x == x)) and not((abs(self.x - x) <= dleft) and (self.y == y)) and not((abs(x - self.x) <= dright) and (self.y == y)):
				print("normal")
			else:
				if not((abs(self.y - y) <= dup) and (self.x == x)):
					print("up")
				if not((abs(y - self.y) <= ddown) and (self.x == x)):
					print("down")
				if not((abs(self.x - x) <= dleft) and (self.y == y)):
					print("left")
				if not((abs(x - self.x) <= dright) and (self.y == y)):
					print("right")
				print("down:",ddown)
				global hp
				if (hp >= 1):
					hp -= 1
		else:
			bombs.pop(bombs.index(self))
			
			
class bonus():
	def __init__(self,x,y,bonustype):
		self.x = x
		self.y = y
		self.bonustype = bonustype
		self.cooldown = 3000
	def draw(self, window):
		if (self.bonustype == 1):
			window.blit(bonusdraw,(self.x, self.y))
		if (self.bonustype == 2):
			window.blit(bonusdraw1,(self.x, self.y))
class buff():
	def __init__(self,bonustype,cooldown, rangex):
		self.bonustype = bonustype
		self.cooldown = cooldown
		self.rangex = rangex
		self.last = pygame.time.get_ticks()
		self.end = False

	def use(self):
		if (now - self.last >= self.cooldown):
			now = pygame.time.get_ticks()
			self.end = True
			if (bonustype == 1):
				spd = 20
			elif (bonustype == 2):
				antidie = False
	def dobuff(self,bonustype):
		global spd
		global antidie
		if (bonustype == 1):
			spd = 40
		elif (bonustype == 2):
			antidie == True
xz = 90
xy = 90
for i in range(0,6):
	xy = 90
	for iceblock in range(0,6):
		ice.append(blocked((xz),(xy)))
		xy += 80
	xz += 80
skills.append(skill(680,40,1000,0))
def diedly():
	global died
	died = True
def checkf():
	flajok = 1
	for bomb in bombs:
			if (bomb.x == x) and (bomb.y == y):
				flajok = 0
	return flajok
def buff(typebuff):
	if (typebuff == 1):
		buffs.append(buff(1),(10000), (0))
	if (typebuff == 2):
		buffs.append(buff(2),(5000), (0))
def wavebomb(ax1,ay1):
	global ax
	global ay
def blockdefense(x,typex,y, kx, ky):
	if (typex == 1) and (x % 80 == 50):
		ret = 0
	elif (typex == 2) and (x % 80 == 10) and (y % 80 == 50):
		ret = 0
	else:
		ret = 1
	for blockd in ice:
		if (blockd.x == kx) and (blockd.y == ky):
			ret = 0
	return ret
			 
def drawnupdate(ax,ay):
	global AnimCount
	global boombombtime
	global actbomb
	global drawbomb
	global x1
	global y1
	global right
	global left
	global up
	global down
	global died
	y1 = 50
	#blockdraw()
	window.fill((45,45,45))
	text1 = int_font.render("Здоровье:" , 1, (255,0,0))
	text2 = int_font.render("Энергия: ", 1, (0,0,255))
	window.blit(text1, (0,660))
	window.blit(text2, (0,675))
	window.blit(background,(0,0))
	if (hp > 0):
		if (hp >= 7):
			pygame.draw.rect(window, GREEN, (70, 664, round(59*hp),10))
		elif (hp >= 4):
			pygame.draw.rect(window, YELLOW, (70, 664, round(59*hp),10))
		elif (hp >= 1):
			pygame.draw.rect(window, RED, (70, 664, round(59*hp),10))
	if (mp > 0):
		if (mp >= 4):
			pygame.draw.rect(window, BLUE, (70, 679, round(59*mp),10))
		elif (mp >= 1):
			pygame.draw.rect(window, LIGHT_BLUE, (70, 679, round(59*mp),10))
	window.blit(gran,(0,0))
	for k in range(1,9):
		x1 = 50
		for i in range(1,9):
			window.blit(block[0], (x1,y1))
			x1 += 80
		y1 += 80
#		print(x1, y1)
#	print("drawbomb: ",drawbomb)
#	print("actbomb: ", actbomb)
#	boombombtime = 0
	if (drawbomb == True):
		if (actbomb == False):
			window.blit(bomba[0], (ax, ay))
#		pygame.draw.rect(window, (0,0,255),(ax,ay,width,height))
		elif (boombombtime >= 0) and (boombombtime <= 27):
			window.blit(bomba[1],(ax, ay))	
		elif (boombombtime >= 28) and (boombombtime <= 52):
			window.blit(bomba[2],(ax, ay))
		elif (boombombtime >= 53) and (boombombtime <= 60):
			window.blit(bomba[3],(ax, ay))
			window.blit(laser[0],(ax-80, ay-80))
			print(ax, ay, x, y)
			print("died : ",died)
#				pass
		actbomb = True
	if (boombombtime < 60) and (actbomb == True):
		boombombtime += 1
		print(boombombtime)
	if (boombombtime == 60) and (actbomb == True):
		wavebomb(ax,ay)
		maxdrawbomb = 0
		boombombtime = 0
		actbomb = False
		drawbomb = False
		print(drawbomb)
	if AnimCount +1 >= 30:
		AnimCount = 0 
	if left:
		window.blit(walkleft[0],(x, y))
#		pygame.draw.rect(window, (0,0,255),(x,y,width,height))
		AnimCount += 1
	elif right:
		window.blit(walkright[0],(x, y))
#		pygame.draw.rect(window, (0,0,255),(x,y,width,height))		
		AnimCount += 1
	elif up:
		window.blit(walkup[0],(x, y))
#		pygame.draw.rect(window, (0,0,255),(x,y,width,height))
		AnimCount += 1
	elif down:
#		pygame.draw.rect(window, (0,0,255),(x,y,width,height))
		window.blit(walkdown[0],(x, y))
		AnimCount += 1
	else:
		if (positionbool == 'right'):
			window.blit(walkright[0],(x, y))
		elif (positionbool == 'left'):
			window.blit(walkleft[0],(x, y))
		elif (positionbool == 'up'):
			window.blit(walkup[0],(x, y))
		elif (positionbool == 'down'):
			window.blit(walkdown[0],(x, y))
#		window.blit(nowalk[0],(x, y))
#		pygame.draw.rect(window, (0,0,255),(x,y,width,height))
	#30 FPS //например, 5 при 6 спрайтах
	for skillz in skills:
		skillz.draw(window)
	for iceblock in ice:
		if (died == False):
			iceblock.draw(window)
	for bonuz in bonusarr:
		if (died == False):
			bonuz.draw(window)
#			pygame.display.update()
	for enem in enemys:
#		отрисовка мобов в окне
		if (died == False):
			enem.draw(window)
	for bomb in bombs:
		if (died == False):
			bomb.draw(window)
#			pygame.display.update()
#	window.fill((0,0,0))
#	pygame.draw.rect(window, (0,0,255),(x,y,width,height))
#	drawdie(died)
	if (died == True):
		window.blit(gameover, (0,0))

	#pygame.display.update()
#gener_ice_blocks()
while game:
	pygame.time.delay(30)
#	clock.tick(15)
	for event in pygame.event.get():
		if (event.type == pygame.QUIT):
			exit()
#	for bombs in maxbombs:
#		if bombs.x 
	keys = pygame.key.get_pressed()
	if keys[pygame.K_LEFT] and (x > 10) and (died == False) and (blockdefense(x,2,y,x-spd,y) and left == False):
#		z = blockdefense(x,2,y)
#		if (z and left == False):
		x -= spd
		left = True
		right = False
		down = False
		up = False
	elif keys[pygame.K_RIGHT] and (x < (maxw - width) - 10) and (died == False) and (blockdefense(x,2,y,x+spd,y) and right == False):
#		z = blockdefense(x,2,y)
#		if (z and right == False):
		x += spd
		left = False
		up = False
		down = False
		right = True
	elif keys[pygame.K_UP] and (y > 10) and (died == False) and (blockdefense(x,1,y,x,y-spd) and up == False):
#		z = blockdefense(x,1,y)
#		if (z and up == False):
			y -= spd
			up = True
			down = False
			right = False
			left = False 
	elif keys[pygame.K_DOWN] and (y < (maxh - height) - 10) and (died == False) and (blockdefense(x,1,y,x,y+spd) and down == False):
#		z = blockdefense(x,1,y)
#		if (z and down == False):
		y += spd
		down = True
		up = False
		right = False
		left = False
#			pass
	elif keys[pygame.K_s]:
#		if (currentbomb < maxbomb):
#		bomb(x,y)
		if (drawbomb != True):
			drawbomb = True
			maxdrawbomb += 1
			ax = x
			ay = y
	elif keys[pygame.K_f] and checkf() and bombcooldown:
#		if (currentbomb < maxbomb):
#		bomb(x,y)
		bombcooldown = False
		lastz = pygame.time.get_ticks()
		bombs.append(bomb((x),(y)))
#		bomb.boom()		
	if (enemycount < enemymax):
		enemys.append(enemy((330),(330)))
#		enem.enemy_motion_cooldown()
		enemycount += 1	
		enemylive += 1
		print(drawbomb,ax,ay)
	else:
		if down:
			positionbool = 'down'
		elif up:
			positionbool = 'up'
		elif left:
			positionbool = 'left'
		elif right:
			positionbool = 'right'
		down = False
		up = False
		right = False
		left = False
		AnimCount = 0
	for bonuz in bonusarr:
		if (bonuz.x == x) and (bonuz.y == y):
			bonusarr.pop(bonusarr.index(bonuz))
	for enem in enemys:
		enemydo = True
		if (x == enem.x) and (y == enem.y):
			died = True
		if (boombombtime >= 53) and (boombombtime <= 60) and (((abs(ax - enem.x) <= 80)) and (ay == enem.y) or ((ax == enem.x) and (abs(ay - enem.y)<=80))):
			enemys.pop(enemys.index(enem))
			enemylive -= 1
		#работа интеллекта мобов
		if not (enem.enemy_motion_cooldown()):
			continue
		while(enemydo == True):
			enemyneed = enemyskills[random.randint(0,3)]
			if (enemyneed == 'right') or (enemyneed == 'left'):
				if (enemyneed == 'right') and (enem.x < (maxw - width) - 10) and (died == False) and (enem.coolbool == True) and (blockdefense(enem.x,2,enem.y,enem.x+spd,enem.y)):
					enem.x += spd	
					enem.coolbool = False
#					enem.enemy_motion_cooldown()
					enemydo = False
					break
				elif (enemyneed == 'left') and (enem.x > 10) and  not died  and enem.coolbool and (blockdefense(enem.x,2,enem.y,enem.x-spd,enem.y)):
					enem.x -= spd
					enem.coolbool = False
#					enem.enemy_motion_cooldown()
					enemydo = False
					break
				else:
					break
			elif (enemyneed == 'up') or (enemyneed == 'down'):	
				if (enemyneed == 'up') and (enem.y > 10) and (died == False) and (enem.coolbool == True) and (blockdefense(enem.x,1,enem.y,enem.x,enem.y-spd)):
					enem.y -= spd
					enem.coolbool = False
					enem.enemy_motion_cooldown()
					enemydo = False
					break
				elif (enemyneed == 'down') and (enem.y < (maxh - height) - 10) and (died == False) and (enem.coolbool == True) and (blockdefense(enem.x,1,enem.y,enem.x,enem.y+spd)): 	
					enem.y += spd
					enemydo = False
					enem.coolbool= False
					enem.enemy_motion_cooldown()
					break
				else:
					break

	info = 'bomberman v0.6: ' + str(x) + ':' + str(y)
	pygame.display.set_caption(info)
	if (hp <= 0):
		diedly()
	drawnupdate(ax,ay)
	pygame.display.flip()	
pygame.quit()
