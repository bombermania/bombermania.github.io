import os
import time
import tkinter
from tkinter import *
root = Tk()
WORK_PATH=os.path.abspath(os.getcwd())
def start_menu():
	print(2)
	
bg_image=PhotoImage(file=os.path.join(WORK_PATH,'background.png'))
bg=Label(root,image=bg_image)

root.title("Game Over")
root.geometry("350x250")
btn0 = Button(
	text="Запуск",          	# текст кнопки 
	background="#00BFFF",  # фоновый цвет кнопки
	foreground="#ffffff",     # цвет текста
	padx="78",             # отступ от границ до содержимого по горизонтали
	pady="10",              # отступ от границ до содержимого по вертикали
	font="10",             # высота шрифта
	)
btn0.pack()

btn1 = Button(
	text="Настройки загрузки",
	background="#00BFFF",
	foreground="#ffffff",
	padx="33",
	pady="10",
	font="10",
	)
btn1.pack()

btn2 = Button(
	text="Добавление своих уровней",
	background="#00BFFF",
	foreground="#ffffff",
	padx="5",
	pady="10",
	font="10",
	)
btn2.pack()
#bg.pack()
#end()	
root.mainloop()
	
