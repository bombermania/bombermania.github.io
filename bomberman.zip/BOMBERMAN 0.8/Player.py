#from pygame.sprite import Sprite
left = right = up = down = positionbool = False
class Player():
	def __init__(self, x, y):
		self.x = x
		self.y = y
#		self.hp = hp
#		self.mp = mp
	def draw(self, window):
		global left
		global right
		global down
		global up
		#window.blit(bomba[0], (self.x, self.y))
		if left:
			window.blit(walkleft[0],(self.x, self.y))
#			pygame.draw.rect(window, (0,0,255),(x,y,width,height))
			AnimCount += 1
		elif right:
			window.blit(walkright[0],(self.x, self.y))
#			pygame.draw.rect(window, (0,0,255),(x,y,width,height))		
			AnimCount += 1
		elif up:
			window.blit(walkup[0],(self.x, self.y))
#			pygame.draw.rect(window, (0,0,255),(x,y,width,height))
			AnimCount += 1
		elif down:
#			pygame.draw.rect(window, (0,0,255),(x,y,width,height))
			window.blit(walkdown[0],(self.x, self.y))
			AnimCount += 1
		else:
			if (positionbool == 'right'):
				window.blit(walkright[0],(self.x, self.y))
			elif (positionbool == 'left'):
				window.blit(walkleft[0],(self.x, self.y))
			elif (positionbool == 'up'):
				window.blit(walkup[0],(self.x, self.y))
			elif (positionbool == 'down'):
				window.blit(walkdown[0],(self.x, self.y))
 
