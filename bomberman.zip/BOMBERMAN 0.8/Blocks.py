class wall():
	def __init__(self, x, y):
		self.x = x
		self.y = y
	def draw(self,window):
		window.blit(wall[0],(self.x, self.y))
