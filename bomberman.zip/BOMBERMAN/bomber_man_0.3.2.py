import pygame
import math
from tkinter import *
pygame.init()
maxw = 640
maxh = 640
#640/20 = 32 / 2 = 16 движений в одну сторону максимально
maxbomb = []
#########################################################
# отвечает за сам процесс, желательно не трогать ВООБЩЕ!
global game
game = 1
#########################################################
window = pygame.display.set_mode((maxw, maxh))
pygame.display.set_caption("Bomberman")
background = pygame.image.load('images/background.png')
walkright = [pygame.image.load('images/bomberman.png')]
walkleft = [pygame.image.load('images/bomberman.png')]
walkup = [pygame.image.load('images/bomberman.png')]
walkdown = [pygame.image.load('images/bomberman.png')]
nowalk = [pygame.image.load('images/bomberman.png')]
laser = [pygame.image.load('images/laser.png'), pygame.image.load('images/laser1.png')]
bomb = [pygame.image.load('images/bomb0.png'), pygame.image.load('images/bomb1.png'), pygame.image.load('images/bomb2.png'), pygame.image.load('images/bomb3.png')]
##########################################################
#глобальные переменные - для событий бомб
global ax
global ay
global drawbomb
global boombombtime
global actbomb
ax = 0
ay = 0
boombombtime = 0
actbomb = False
##########################################################
AnimCount = 0
maxbomb = 3
maxdrawbomb = 0
currentbomb = 0
checkbomb = 0
clock = pygame.time.Clock()
drawbomb = False
left = False
right = False
up = False
down = False
###########################################################
#class bomb():
#	def __init__(self,x,y):
#		self.x = x
#		self.y = y
#	def draw(self, window):
#		pygame.draw.circle(window, (self.x,self.x))

#def bomb(x,y):
#	global drawbomb
#	global ax
#	global ay
#	drawbomb = True
#	ax = x
#	ay = y
def end():
	root = Tk()
	root.title("Game Over")
	root.geometry("350x250")
	btn = Button(text="Ok",          	# текст кнопки 
             background="#00BFFF",  # фоновый цвет кнопки
             foreground="#ffffff",     # цвет текста
             padx="31",             # отступ от границ до содержимого по горизонтали
             pady="5",              # отступ от границ до содержимого по вертикали
             font="10",             # высота шрифта
             command = wavebomb(1,1)
             )
	btn.pack()
#	root.mainloop()
def wavebomb(ax1,ay1):
	global ax
	global ay	
def blockdraw(y1,x1):
	while (y1 != 0):
		while (x1 != 0):
			window.blit(bomb[0],(x1, y1))
			x1 -= 40
		y1 -= 40	
def drawnupdate(ax,ay):
	global AnimCount
	global boombombtime
	global actbomb
	global drawbomb
	window.blit(background,(0,0))
	blockdraw(640,640)
#	print("drawbomb: ",drawbomb)
#	print("actbomb: ", actbomb)
#	boombombtime = 0
	if (drawbomb == True):
		if (actbomb == False):
			window.blit(bomb[0], (ax, ay))
#		pygame.draw.rect(window, (0,0,255),(ax,ay,width,height))
		elif (boombombtime >= 0) and (boombombtime <= 27):
			window.blit(bomb[1],(ax, ay))	
		elif (boombombtime >= 28) and (boombombtime <= 52):
			window.blit(bomb[2],(ax, ay))
		elif (boombombtime >= 53) and (boombombtime <= 60):
			window.blit(bomb[3],(ax, ay))
			window.blit(laser[0],(ax+20, ay))
			window.blit(laser[0],(ax+40, ay))
			window.blit(laser[0],(ax-20, ay))	
			window.blit(laser[0],(ax-40, ay))
			window.blit(laser[1],(ax, ay - 20))	
			window.blit(laser[1],(ax, ay - 40))
			window.blit(laser[1],(ax, ay + 20))	
			window.blit(laser[1],(ax, ay + 40))		
# 			это нужно сократить как можно быстрее, набросок
			print(ax, ay, x, y)	
			if ((abs(ax - x) <= 40) or (abs(ay - y)<=40)):
				global game
				game = 0
				pass						
#		boombombtime = 0
		actbomb = True
	if (boombombtime < 60) and (actbomb == True):
		boombombtime += 1
		print(boombombtime)
	if (boombombtime == 60) and (actbomb == True):
#		pygame.draw.rect(window, (0,255,0),(ax,ay,width,height))
		wavebomb(ax,ay)
		maxdrawbomb = 0
		boombombtime = 0
		actbomb = False
		drawbomb = False
		print(drawbomb)
	if AnimCount +1 >= 30:
		AnimCount = 0 
	if left:
		window.blit(walkleft[0],(x, y))
		AnimCount += 1
	elif right:
		window.blit(walkright[0],(x, y))
		AnimCount += 1
	elif up:
		window.blit(walkup[0],(x, y))
		AnimCount += 1
	elif down:
		window.blit(walkdown[0],(x, y))
		AnimCount += 1
	else:
		window.blit(nowalk[0],(x, y))
	#30 FPS // 5 при 6 спрайтах

#	window.fill((0,0,0))
#	pygame.draw.rect(window, (0,0,255),(x,y,width,height))	
	pygame.display.update()
###########	
global x
global y
x = 100
y = 100
width = 20
height = 20
spd = 10
###########
while game:
#	pygame.time.delay(30)
	clock.tick(30)
	for event in pygame.event.get():
		if (event.type == pygame.QUIT):
			exit()	
#	for bombs in maxbombs:
#		if bombs.x 
	keys = pygame.key.get_pressed()
	if keys[pygame.K_LEFT] and (x > 0):
		x -= spd
		left = True
		right = False
	elif keys[pygame.K_RIGHT] and (x < (maxw - width)):
		x += spd
		left = False
		up = False
		down = False
		right = True
	elif keys[pygame.K_UP] and (y > 0):
		y -= spd
		up = True
		down = False
		right = False
		left = False 
	elif keys[pygame.K_DOWN] and (y < (maxh - height)):
		y += spd
		down = True
		up = False
		right = False
		left = False
	elif keys[pygame.K_s]:
#		if (currentbomb < maxbomb):
#		bomb(x,y)
		if (drawbomb != True) or (maxdrawbomb < 3):
			drawbomb = True
			maxdrawbomb += 1
			ax = x
			ay = y
		print(drawbomb,ax,ay)	
		#screenshot = screen.copy()
	else:
		down = False
		up = False
		right = False
		left = False
		AnimCount = 0
	print("drawnupdate: drawbomb:", drawbomb)
	drawnupdate(ax,ay)
	
		
pygame.quit()
